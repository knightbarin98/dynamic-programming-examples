import edu.princeton.cs.algs4.StdIn;
import edu.princeton.cs.algs4.StdOut;
import edu.princeton.cs.algs4.StdRandom;

public class RandomWord {

    public static void main(String[] args) {
        int count = 1;
        String champion = "";
        while (!StdIn.isEmpty()){
                       String tmp = StdIn.readString();
            boolean newchampion = StdRandom.bernoulli((double) 1/count);
            if(newchampion){
                champion = tmp;
            }
            count++; 
        }

        StdOut.print(champion);
    }
    
}
